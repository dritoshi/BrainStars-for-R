### R code from vignette source 'brainstars.Rnw'

###################################################
### code chunk number 1: brainstars.Rnw:61-62
###################################################
library(brainstars)


###################################################
### code chunk number 2: brainstars.Rnw:67-68
###################################################
my.eset <- getBrainStarsExpression("1439627_at")


###################################################
### code chunk number 3: brainstars.Rnw:74-77
###################################################
ids <- c("1439627_at", "1439631_at", "1439633_at")
my.esets <- getBrainStarsExpression(ids)
my.esets


###################################################
### code chunk number 4: brainstars.Rnw:81-82
###################################################
my.mat <- exprs(my.esets)


###################################################
### code chunk number 5: brainstars.Rnw:88-92
###################################################
getBrainStarsFigure("1439627_at", "exprgraph",   "png")
getBrainStarsFigure("1439627_at", "exprmap",     "pdf")
getBrainStarsFigure("1439627_at", "switchgraph", "png")
getBrainStarsFigure("1439627_at", "switchhist",  "png")


###################################################
### code chunk number 6: brainstars.Rnw:111-113
###################################################
recep.rjson <- getBrainStars("receptor/10,5")
recep.count <- getBrainStars("receptor/count")


###################################################
### code chunk number 7: brainstars.Rnw:116-119
###################################################
recep.gns <- geneNames(recep.rjson)
recep.gss <- geneSymbols(recep.rjson)
recep.ids <- probeSetIDs(recep.rjson)


###################################################
### code chunk number 8: brainstars.Rnw:128-129
###################################################
mk.genes.count <- getBrainStarsMarker("high/LS/count")


###################################################
### code chunk number 9: brainstars.Rnw:133-134
###################################################
ms.genes.list <- getBrainStarsMultistate("low/SCN/all")


###################################################
### code chunk number 10: brainstars.Rnw:138-139
###################################################
os.genes.count <- getBrainStarsOnestate("count")


###################################################
### code chunk number 11: brainstars.Rnw:144-147
###################################################
gfc.genes1.count <- getBrainStarsGeneFamCat("tf//count")
gfc.genes2.list  <- getBrainStarsGeneFamCat("tf/terminal/all")
gfc.genes3.count <- getBrainStarsGeneFamCat("tf/terminal/count")


###################################################
### code chunk number 12: brainstars.Rnw:152-153
###################################################
os.genes <- getBrainStarsNtNh("high/SCN/ME/all")


